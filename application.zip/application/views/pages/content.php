<a id="services"></a>
<div class="content-section-a">

<div class="container">
<div class="row">
<div class="col-lg-5 col-sm-6">
<hr class="section-heading-spacer">
<div class="clearfix"></div>
<h2 class="section-heading"><?php echo $content_heading; ?><br>Special Thanks</h2>
<p class="lead"><?php echo $content_a; ?> <a href=<?php echo $content_a_link_ref; ?>><?php echo $content_a_link_name; ?></a> <?php echo $content_b; ?></p>
</div>
<div class="col-lg-5 col-lg-offset-2 col-sm-6">
<img class="img-responsive" src = <?php echo $src; ?> alt="">
</div>
</div>

</div>
<!-- /.container -->

</div>