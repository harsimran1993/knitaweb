<section id="gallery">
	<div onclick="" class="view-wrap" style="background-color: LightSalmon;">
		<div onclick="" class="view" >
			<div class="view-back">
				<img style="margin-top:25%" src="<?php echo base_url("assets/image-small/4.jpg");  ?>" alt="ramsum"/>
				<img src="<?php echo base_url("assets/image-small/5.jpg");  ?>" alt="ramsum"/>
				<a href="https://play.google.com/store/apps/details?id=com.purefaithstudio.gurbani&hl=en">&rarr;</a>
			</div>
			<img class="remove" src="<?php echo base_url("assets/image/nitnem.jpg");  ?>" alt="ramsum"/>
		</div>
	</div><div onclick="" class="view-wrap" style="background-color: wheat;">
		<div onclick="" class="view">
			<div class="view-back">
				<img style="margin-top:25%" src="<?php echo base_url("assets/image-small/7.jpg");  ?>" alt="ramsum"/>
				<img src="<?php echo base_url("assets/image-small/4.jpg");  ?>" alt="ramsum"/>
				<a href="#">&rarr;</a>
			</div>
			<img class="remove" src="<?php echo base_url("assets/image/ramsum.jpg");  ?>" alt="ramsum"/>
		</div>
	</div><div onclick="" class="view-wrap" style="background-color: AntiqueWhite;">
		<div onclick="" class="view">
			<div class="view-back">
				<img style="margin-top:25%" src="<?php echo base_url("assets/image-small/5.jpg");  ?>" alt="ramsum"/>
				<a href="https://github.com/harsimran1993/DIGIWM">&rarr;</a>
			</div>
			<img class="remove" src="<?php echo base_url("assets/image/digiwm.png");  ?>" alt="ramsum"/>
		</div>
	</div><div onclick="" class="view-wrap" style="background-color: whitesmoke;">
		<div onclick="" class="view">
			<div class="view-back">
				<img style="margin-top:25%" src="<?php echo base_url("assets/image-small/7.jpg");  ?>" alt="ramsum"/>
				<img src="<?php echo base_url("assets/image-small/4.jpg");  ?>" alt="ramsum"/>
				<a href="https://play.google.com/store/apps/details?id=com.purefaithstudio.ZombieBird&hl=en">&rarr;</a>
			</div>
			<img class="remove" src="<?php echo base_url("assets/image/idlebirds.jpg");  ?>" alt="ramsum"/>
		</div>
	</div>
</section>
