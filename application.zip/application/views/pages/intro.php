<section id="about" class="intro-header">
	<div class="intro-message">
		<h1 class="animated bounceInDown">
			<span><?php echo $about_title; ?></span>
			<span class="cd-headline rotate-1">
				<span class="cd-words-wrapper no-flick" style="width:100%;">
					<b class="is-visible " style="width:100%;"><?php echo $about_head1; ?></b>
					<b style="width:100%;"><?php echo $about_head2; ?></b>
					<b style="width:100%;"><?php echo $about_head3; ?></b>
				</span>
			</span>
		</h1>
	</div>
	<div class="intro-divider" ></div>
	<div>
		<a class="contact" href="#footer"><b>HIRE ME</b></a>
    </div>
     
</section>