

<a id="services"></a>
<section class="parallax">
	<div class="container">
		<div class="row" style="height:6em">
		</div>
		<div class="row">
			<div class="col-sm-6">
				<div class="panel panel-default" style="min-height:400px;border-radius:0 25% 10%; overflow:hidden;">
					<div class="panel-heading">
						<h2>Web Applications</h2>
	 				</div>
					<div class="panel-body lead">
		            	<ul class="servicelist">
		            		<li>
		            			Static Websites
	            			</li>
	            			<li>
	            				Dynamic Websites
	            			</li>
	            			<li>
	            				E-commerce
	            			</li>
	            			<li>
	            				Portfolios
	            			</li>
	            		</ul>
					</div>
				</div>
			</div>
			<div class="col-sm-6">
				<div class="panel panel-default" style="min-height:400px;border-radius:25% 0 25% 10%; overflow:hidden;">
					<div class="panel-heading">
						<h2>Mobile Applications - Android</h2>
					</div>
					<div class="panel-body lead">
		            	<ul class="servicelist">
		            		<li>
		            			Casual Applications
		            		</li>
		            		<li>
		            			Application As a Service
		            		</li>
		            		<li>
		            			E-commerce Application
		            		</li>
		            		<li>
		            			Gaming Apps
		            		</li>
		            	</ul>
					 </div>
				</div>
			</div>
		</div>
		<div class="row" style=" text-align:center;">	
    		<div class="col-xs-2" style="background-color:yellow;"></div>
    		<div class="col-xs-8" style="background-color:yellow; color:black;">SERVICES</div>
    		<div class="col-xs-2" style="background-color:yellow;"></div>
		</div>
		<div class="row" style="height:5em">
		</div>
	</div>
</section>