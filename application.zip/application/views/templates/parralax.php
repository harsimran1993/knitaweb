

<a id="services"></a>
<div class="parallax">
	<div class="container">
      <div class="row" style="height:6em">
      </div>
      <div class="row">
        <div class="col-sm-6">
          <div class="panel panel-default" style="min-height:400px;">
            <div class="panel-body lead">
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed hendrerit adipiscing blandit. Aliquam placerat, velit a fermentum fermentum, mi felis vehicula justo, a dapibus quam augue non massa. Duis euismod, augue et tempus consequat, lorem mauris porttitor quam, consequat ultricies mauris mi a metus. Phasellus congue, leo sed ultricies tristique, nunc libero tempor ligula, at varius mi nibh in nisi. Aliquam erat volutpat. Maecenas rhoncus, neque facilisis rhoncus tempus, elit ligula varius dui, quis amet. 
            </div>
          </div>
        </div>
        <div class="col-sm-6">
          <div class="panel panel-default" style="min-height:400px;">
            <div class="panel-body lead">
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed hendrerit adipiscing blandit. Aliquam placerat, velit a fermentum fermentum, mi felis vehicula justo, a dapibus quam augue non massa. Duis euismod, augue et tempus consequat, lorem mauris porttitor quam, consequat ultricies mauris mi a metus. Phasellus congue, leo sed ultricies tristique, nunc libero tempor ligula, at varius mi nibh in nisi. Aliquam erat volutpat. Maecenas rhoncus, neque facilisis rhoncus tempus, elit ligula varius dui, quis amet. 
            </div>
          </div>
        </div>
      </div>
		<div class="row" style=" text-align:center;">	
    		<div class="col-xs-2" style="background-color:yellow;"></div>
    		<div class="col-xs-8" style="background-color:yellow;">hi</div>
    		<div class="col-xs-2" style="background-color:yellow;"></div>
		</div>
	
      <div class="row" style="height:5em">
      </div>
	</div>
</div>