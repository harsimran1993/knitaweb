	
		<div id="footer">
			<p>Made by Me</p>
			<ul class="list-inline intro-social-buttons">
				<li>
					<a href="https://www.facebook.com/harsimran.singh.01476802711" class="btn btn-default btn-lg"><i class="fa fa-facebook fa-fw"></i></a>
				</li>
				<li>
					<a href="#" class="btn btn-default btn-lg"><i class="fa fa-twitter fa-fw"></i></a>
				</li>
				<li>
					<a href="#" class="btn btn-default btn-lg"><i class="fa fa-linkedin fa-fw"></i></a>
				</li>
			</ul>
			<em>Unless otherwise stated, content is copyright &copy; 2017 <a href="/">Harsimran Singh</a> and code samples are licensed under <a href="http://www.opensource.org/licenses/mit-license.php">MIT</a></em>
		</div>
		<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.js"></script>
		<script type="text/javascript" src="<?php echo base_url("assets/js/jquery.hoverfold.js"); ?>"></script>
	</body>
</html>