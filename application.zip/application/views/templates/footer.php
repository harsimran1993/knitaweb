		
		<div style=" text-align:center;">
			<p>Made by Harsimran Singh</p>
			<em>&copy; purefaithstudio @2017</em>
		</div>
	</body>
</html>